import{j as e}from"./utils-DgjX4Vtn.js";function m({message:n="Memuat...",size:r="medium",fullPage:s=!1}){const t={small:24,medium:40,large:56}[r],i={display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:s?"4rem 1rem":"2rem",gap:"1rem"},o={width:t,height:t,border:"3px solid var(--color-border)",borderTopColor:"var(--color-accent)",borderRadius:"50%",animation:"spin 1s linear infinite"},a={fontSize:r==="small"?"var(--text-sm)":"var(--text-base)",color:"var(--color-text-secondary)"};return e.jsxs("div",{role:"status","aria-live":"polite",style:i,children:[e.jsx("div",{style:o}),e.jsx("span",{style:a,children:n}),e.jsx("style",{children:`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `})]})}export{m as L};
//# sourceMappingURL=LoadingState-DuaCAPcx.js.map
