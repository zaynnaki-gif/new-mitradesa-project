import{j as a}from"./utils-DgjX4Vtn.js";import{u as v,r as s,L as x}from"./vendor-CTlt5zDm.js";import{u as f,b as h,P as c}from"./useSeo-CbckFdy7.js";import{A as j}from"./constants-f17xfYb8.js";import"./index--X4_EbOb.js";import{L as k}from"./LoadingState-DuaCAPcx.js";import{E as y}from"./ErrorState-C01LEyI0.js";import{s as w}from"./sanitize-BCusOTv_.js";import{E,a as L}from"./EditorialSection-DTBI8hks.js";import"./useLayanan-S5zrz1Sh.js";function R(){const{slug:t}=v(),{data:n}=f(),[r,d]=s.useState(null),[b,i]=s.useState(!0),[m,l]=s.useState(null),g=(n==null?void 0:n.namaDesa)||"Desa";h({title:r?r.judul:"Memuat...",description:(r==null?void 0:r.excerpt)||`Halaman ${g}`,canonical:r?`${window.location.origin}/halaman/${t}`:void 0});const u=async()=>{i(!0),l(null);try{const o=await fetch(`${j}/public/halaman/${encodeURIComponent(t)}`);if(!o.ok)throw o.status===404?new Error("Halaman tidak ditemukan"):new Error("Gagal memuat halaman");const p=await o.json();if(p.success)d(p.data);else throw new Error("Gagal memuat halaman")}catch(o){l(o instanceof Error?o.message:"Terjadi kesalahan"),d(null)}finally{i(!1)}};return s.useEffect(()=>{if(!t){i(!1),l("Slug halaman tidak valid");return}u()},[t]),b?a.jsx(c,{children:a.jsx(k,{message:"Memuat halaman...",fullPage:!0})}):m||!r?a.jsx(c,{children:a.jsx(y,{title:"Halaman Tidak Ditemukan",message:m||"Halaman yang Anda cari tidak tersedia.",onRetry:t?u:void 0})}):a.jsxs(c,{children:[a.jsx("nav",{className:e.breadcrumb,"aria-label":"Breadcrumb",children:a.jsxs("div",{className:e.breadcrumbContainer,children:[a.jsx(x,{to:"/",className:e.breadcrumbLink,children:"Beranda"}),a.jsx("span",{className:e.breadcrumbSeparator,children:"/"}),a.jsx("span",{className:e.breadcrumbCurrent,children:r.judul})]})}),a.jsx(E,{title:r.judul}),a.jsx(L,{children:a.jsxs("div",{className:e.contentContainer,children:[r.excerpt&&a.jsx("p",{className:e.pageExcerpt,children:r.excerpt}),r.konten&&a.jsx("div",{className:e.pageBody,dangerouslySetInnerHTML:{__html:w(r.konten)}})]})}),a.jsx("div",{className:e.pageFooter,children:a.jsx("div",{className:e.footerContainer,children:a.jsxs(x,{to:"/",className:e.backLink,children:[a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",width:"20",height:"20",children:[a.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),a.jsx("polyline",{points:"12,19 5,12 12,5"})]}),"Kembali ke Beranda"]})})})]})}const e={breadcrumb:`
    background-color: var(--color-bg-surface);
    border-bottom: 1px solid var(--color-border);
    padding: var(--space-3) var(--space-4);
  `,breadcrumbContainer:`
    max-width: 800px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    gap: var(--space-2);
    font-size: var(--text-sm);
    flex-wrap: wrap;
  `,breadcrumbLink:`
    color: var(--color-text-secondary);
    text-decoration: none;
    transition: color var(--transition-fast);
  `,breadcrumbSeparator:`
    color: var(--color-text-muted);
  `,breadcrumbCurrent:`
    color: var(--color-text-primary);
    font-weight: 500;
  `,contentContainer:`
    max-width: 800px;
    margin: 0 auto;
  `,pageExcerpt:`
    font-size: var(--text-lg);
    color: var(--color-text-secondary);
    line-height: 1.7;
    margin-bottom: var(--space-6);
    padding-bottom: var(--space-6);
    border-bottom: 1px solid var(--color-border);
  `,pageBody:`
    font-size: var(--text-base);
    line-height: 1.8;
    color: var(--color-text-primary);
  `,pageFooter:`
    padding: var(--space-6) var(--space-4);
    border-top: 1px solid var(--color-border);
    background-color: var(--color-bg-surface);
  `,footerContainer:`
    max-width: 800px;
    margin: 0 auto;
  `,backLink:`
    display: inline-flex;
    align-items: center;
    gap: var(--space-2);
    padding: var(--space-2) var(--space-4);
    font-size: var(--text-sm);
    font-weight: 500;
    color: var(--color-navy-base);
    background-color: var(--color-bg-base);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    text-decoration: none;
    transition: all var(--transition-fast);
  `};export{R as default};
//# sourceMappingURL=HalamanPage-DSXsEjfM.js.map
