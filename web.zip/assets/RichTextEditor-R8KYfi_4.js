import{j as e,p as c}from"./utils-DgjX4Vtn.js";import{r as u}from"./vendor-CTlt5zDm.js";import{R as p}from"./editor-3votdS3a.js";const i={toolbar:[[{header:[1,2,3,!1]}],["bold","italic","underline","strike"],[{list:"ordered"},{list:"bullet"}],[{indent:"-1"},{indent:"+1"}],["link","image"],["clean"]]},b=["header","bold","italic","underline","strike","list","bullet","indent","link","image"];function g({value:o,onChange:n,placeholder:l="Tulis konten di sini...",readOnly:t=!1,height:s=300}){const r=u.useMemo(()=>({...i,toolbar:{...i.toolbar}}),[]),a=d=>{const m=c.sanitize(d);n(m)};return e.jsxs("div",{style:{position:"relative"},children:[e.jsx(p,{theme:"snow",value:o,onChange:a,modules:r,formats:b,placeholder:l,readOnly:t,style:{height:s,marginBottom:"2.25rem"}}),t&&e.jsx("style",{children:`
          .ql-toolbar { display: none; }
          .ql-container { border: none; }
          .ql-editor { padding: 0; }
          .ql-editor.ql-blank::before { display: none; }
        `})]})}export{g as R};
//# sourceMappingURL=RichTextEditor-R8KYfi_4.js.map
