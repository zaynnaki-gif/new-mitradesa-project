import{p as r}from"./utils-DgjX4Vtn.js";function n(i){return i?r.sanitize(i):""}export{n as s};
//# sourceMappingURL=sanitize-BCusOTv_.js.map
